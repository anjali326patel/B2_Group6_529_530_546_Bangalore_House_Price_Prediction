from flask import Flask, request, jsonify
import util

app = Flask(__name__, static_url_path='', static_folder='client')
@app.route('/')
def index():
    return app.send_static_file('app.html')
@app.route('/api/get_location_names', methods=['GET'])
def get_location_names():
    response = jsonify({
        'locations': util.get_location_names()
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response

@app.route('/api/location_stats', methods=['GET'])
def location_stats():
    try:
        location = request.args.get('location', '')
        if not location:
            # No location passed -> just return empty object
            return jsonify({})
        stats = util.get_location_stats(location)
        # If no stats, still return {} instead of None
        return jsonify(stats if isinstance(stats, dict) else {})
    except Exception as e:
        print("Error in /api/location_stats:", e)
        # Never crash the server – just return empty {} for safety
        return jsonify({})


@app.route('/api/predict_home_price', methods=['GET', 'POST'])
def predict_home_price():
    total_sqft = float(request.form['total_sqft'])
    location = request.form['location']
    bhk = int(request.form['bhk'])
    bath = int(request.form['bath'])

    estimated_price = util.get_estimated_price(location, total_sqft, bhk, bath)
    market_stats = util.get_location_stats(location)   # NEW

    response = jsonify({
        'estimated_price': estimated_price,
        'market_stats': market_stats   # NEW FIELD
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response

from flask_ngrok import run_with_ngrok   # ADD THIS AT THE TOP

if __name__ == "__main__":
    print("Starting Python Flask Server For Home Price Prediction...")
    util.load_saved_artifacts()
    app.run(host='0.0.0.0', port=5000)