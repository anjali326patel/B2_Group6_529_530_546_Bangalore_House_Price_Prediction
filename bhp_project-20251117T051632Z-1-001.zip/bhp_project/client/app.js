// =====================
// Global chart handle
// =====================
var multiChart = null;


// =====================
// Helpers for main form
// =====================
function getBHKValue() {
    var uiBHK = document.getElementsByName("uiBHK");
    for (var i = 0; i < uiBHK.length; i++) {
        if (uiBHK[i].checked) {
            return parseInt(uiBHK[i].value);
        }
    }
    return -1;
}

function getBathValue() {
    var uiBathrooms = document.getElementsByName("uiBathrooms");
    for (var i = 0; i < uiBathrooms.length; i++) {
        if (uiBathrooms[i].checked) {
            return parseInt(uiBathrooms[i].value);
        }
    }
    return -1;
}

// =====================
// Single price estimate
// =====================
function onClickedEstimatePrice() {
    console.log("Estimate Price clicked");

    var sqft = document.getElementById("uiSqft");
    var bhk = getBHKValue();
    var bathrooms = getBathValue();
    var location = document.getElementById("uiLocations");
    var estPrice = document.getElementById("uiEstimatedPrice");

    var sqftVal = parseFloat(sqft.value);

    if (!sqftVal || bhk === -1 || bathrooms === -1 || !location.value) {
        estPrice.innerHTML = "<b>Please fill all fields correctly.</b>";
        return;
    }

    var url = "/api/predict_home_price";

    $.post(
        url,
        {
            total_sqft: sqftVal,
            bhk: bhk,
            bath: bathrooms,
            location: location.value
        },
        function (data, status) {
    console.log("Estimate result:", data, "status:", status);

    if (data && data.estimated_price !== undefined) {

        // Show main price
        estPrice.innerHTML = "<b>" + data.estimated_price.toFixed(2) + " Lakh</b>";

        // ------------------------------
        // 🎯 New: Market Meter Logic
        // ------------------------------
        var stats = data.market_stats;
        var meter = document.getElementById("priceMeter");
        var fill = document.getElementById("meterFill");
        var label = document.getElementById("marketLabel");
        var text = document.getElementById("meterText");

        if (stats && stats.median) {
            meter.classList.remove("hidden");

            var predicted = data.estimated_price;
            var median = stats.median;
            var low5 = stats.low_5;
            var high95 = stats.high_95;

            // convert to % along range
            var percent = Math.min(
                100,
                Math.max(0, ((predicted - low5) / (high95 - low5)) * 100)
            );
            fill.style.width = percent + "%";

            // color rules
            var diff = predicted - median;
            if (diff < -10) {
                fill.style.background = "#22c55e";   // green
                label.innerText = "Undervalued (Great Deal)";
            } else if (Math.abs(diff) <= 10) {
                fill.style.background = "#facc15";   // yellow
                label.innerText = "Fair Market Price";
            } else {
                fill.style.background = "#ef4444";   // red
                label.innerText = "Overpriced";
            }

            text.innerText =
                "Median: " + median.toFixed(1) + " L | Range: " +
                low5.toFixed(1) + "–" + high95.toFixed(1) + " L";

        } else {
            meter.classList.add("hidden");
        }

    } else {
        estPrice.innerHTML = "<b>Error getting price</b>";
    }
}

    ).fail(function () {
        estPrice.innerHTML = "<b>Error contacting server</b>";
    });
}

// =====================
// Load locations on load
// =====================
function onPageLoad() {
    console.log("Page loaded, fetching locations...");
    var url = "/api/get_location_names";

    $.get(url, function (data, status) {
        console.log("Got locations:", data, "status:", status);

        if (!data || !data.locations) return;

        var locations = data.locations;

        var uiLocations = document.getElementById("uiLocations");

        var m1 = document.getElementById("multi_loc_1");
        var m2 = document.getElementById("multi_loc_2");
        var m3 = document.getElementById("multi_loc_3");
        var m4 = document.getElementById("multi_loc_4");
        var m5 = document.getElementById("multi_loc_5");
        var multiList = [m1, m2, m3, m4, m5];

        if (uiLocations)
            uiLocations.innerHTML = '<option value="" disabled selected>Choose a Location</option>';

        multiList.forEach(function (sel) {
            if (sel) sel.innerHTML = '<option value="">-- select --</option>';
        });

        locations.forEach(function (loc) {
            if (uiLocations) uiLocations.add(new Option(loc, loc));
            multiList.forEach(function (sel) {
                if (sel) sel.add(new Option(loc, loc));
            });
        });
    });
}

window.onload = onPageLoad;

// =====================
// Chart rendering helper
// =====================
function renderBarChart(canvasId, labels, data) {
    var canvas = document.getElementById(canvasId);
    if (!canvas) return;

    var ctx = canvas.getContext("2d");

    if (multiChart) {
        multiChart.destroy();
    }

    var paletteBg = [
        "rgba(99, 102, 241, 0.8)",
        "rgba(129, 140, 248, 0.8)",
        "rgba(165, 180, 252, 0.8)",
        "rgba(196, 181, 253, 0.8)",
        "rgba(167, 139, 250, 0.8)"
    ];
    var paletteBorder = [
        "rgba(99, 102, 241, 1)",
        "rgba(129, 140, 248, 1)",
        "rgba(165, 180, 252, 1)",
        "rgba(196, 181, 253, 1)",
        "rgba(167, 139, 250, 1)"
    ];

    var bgColors = data.map(function (_, i) {
        return paletteBg[i % paletteBg.length];
    });
    var borderColors = data.map(function (_, i) {
        return paletteBorder[i % paletteBorder.length];
    });

    var shortLabels = labels.map(function (lbl) {
        return lbl.length > 14 ? lbl.slice(0, 14) + "…" : lbl;
    });

    multiChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: shortLabels,
            datasets: [{
                data: data,
                backgroundColor: bgColors,
                borderColor: borderColors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        title: function (context) {
                            var idx = context[0].dataIndex;
                            return labels[idx];
                        },
                        label: function (context) {
                            return context.parsed.y.toFixed(2) + " Lakh";
                        }
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: "#e5e7eb",
                        maxRotation: 0,
                        minRotation: 0,
                        autoSkip: false
                    }
                },
                y: {
                    ticks: { color: "#e5e7eb" },
                    title: {
                        display: true,
                        text: "Price (Lakh)",
                        color: "#e5e7eb"
                    }
                }
            }
        }
    });
}

// =====================
// Multi-location comparison (2–5)
// =====================
function compareMultipleLocations() {
    console.log("Compare multiple locations clicked");

    var sqft = document.getElementById("cmp_sqft").value;
    var bhk = document.getElementById("cmp_bhk").value;
    var bath = document.getElementById("cmp_bath").value;

    if (!sqft) sqft = document.getElementById("uiSqft").value;
    if (!bhk) bhk = getBHKValue();
    if (!bath) bath = getBathValue();

    sqft = parseFloat(sqft);
    bhk = parseInt(bhk);
    bath = parseInt(bath);

    var err = document.getElementById("cmp_error");
    var resultsDiv = document.getElementById("multi_results");
    if (err) {
        err.classList.add("hidden");
        err.innerText = "";
    }
    if (resultsDiv) {
        resultsDiv.innerHTML = "";
    }

    if (!sqft || !bhk || !bath) {
        if (err) {
            err.innerText = "Please fill area/BHK/bath first (either left or right panel).";
            err.classList.remove("hidden");
        }
        return;
    }

    var ids = ["multi_loc_1", "multi_loc_2", "multi_loc_3", "multi_loc_4", "multi_loc_5"];
    var selected = [];
    ids.forEach(function (id) {
        var sel = document.getElementById(id);
        if (sel && sel.value) {
            if (!selected.includes(sel.value)) {
                selected.push(sel.value);
            }
        }
    });

    if (selected.length < 2) {
        if (err) {
            err.innerText = "Select at least 2 locations.";
            err.classList.remove("hidden");
        }
        return;
    }
    if (selected.length > 5) {
        if (err) {
            err.innerText = "Select at most 5 locations.";
            err.classList.remove("hidden");
        }
        return;
    }

    var url = "/api/predict_home_price";

    var promises = selected.map(function (loc) {
        return new Promise(function (resolve, reject) {
            $.post(
                url,
                {
                    total_sqft: sqft,
                    bhk: bhk,
                    bath: bath,
                    location: loc
                },
                function (data, status) {
                    if (data && data.estimated_price !== undefined) {
                        resolve({ location: loc, price: data.estimated_price });
                    } else {
                        reject("No price for " + loc);
                    }
                }
            ).fail(function () {
                reject("Request failed for " + loc);
            });
        });
    });

    Promise.all(promises)
        .then(function (results) {
            var labels = results.map(function (r) { return r.location; });
            var values = results.map(function (r) { return r.price; });

            if (resultsDiv) {
                var html = "";
                results.forEach(function (r) {
                    html += `
                        <div class="compare-card">
                            <h3>${r.location}</h3>
                            <p class="cmp-price">${r.price.toFixed(2)} Lakh</p>
                        </div>
                    `;
                });
                resultsDiv.innerHTML = html;
            }

            renderBarChart("multiChart", labels, values);
            
        })
        .catch(function (e) {
            console.error(e);
            if (err) {
                err.innerText = "Error fetching one or more locations.";
                err.classList.remove("hidden");
            }
        });
}
